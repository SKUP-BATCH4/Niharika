#include<stdio.h>
int main()
{
    char s[9]="8";
    char s1[7]="7";
    int res=strcmp(s,s1);
    printf("%d",res);
}
